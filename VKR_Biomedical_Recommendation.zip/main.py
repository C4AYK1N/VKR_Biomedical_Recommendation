# ФИО: Чайкин Виталий Федорович
# Тема ВКР: Разработка рекомендательной системы на основе обработки биомедицинских данных

"""
Главный запускаемый файл приложения.
Запуск: streamlit run main.py
"""

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import tensorflow as tf
from tensorflow import keras
import pickle
import os

# Создаем папки если их нет
os.makedirs("models", exist_ok=True)
os.makedirs("data", exist_ok=True)

st.set_page_config(
    page_title="Рекомендательная система для анализа ЭКГ",
    page_icon="❤️",
    layout="wide"
)

st.title("❤️ Рекомендательная система для анализа биомедицинских данных")
st.markdown("---")

class Config:
    SAMPLING_RATE = 360
    SEQUENCE_LENGTH = 360
    RANDOM_STATE = 42
    TEST_SIZE = 0.2
    
    ARRHYTHMIA_CLASSES = {
        0: "Нормальный ритм",
        1: "Апноэ", 
        2: "Фибрилляция предсердий",
        3: "Шум",
        4: "Другая аритмия"
    }

config = Config()

class DataLoader:
    def load_simulated_data(self, n_samples=5000):
        np.random.seed(config.RANDOM_STATE)
        X = np.zeros((n_samples, config.SEQUENCE_LENGTH))
        y = np.zeros(n_samples)
        
        for i in range(n_samples):
            t = np.linspace(0, 1, config.SEQUENCE_LENGTH)
            base_ecg = 0.5 * np.sin(2 * np.pi * 1 * t)
            arrhythmia_type = i % 5
            y[i] = arrhythmia_type
            
            if arrhythmia_type == 0:
                X[i] = base_ecg + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
            elif arrhythmia_type == 1:
                X[i] = base_ecg * (0.5 + 0.5 * np.sin(2 * np.pi * 0.1 * t)) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
            elif arrhythmia_type == 2:
                X[i] = base_ecg + 0.3 * np.random.normal(size=config.SEQUENCE_LENGTH) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
            elif arrhythmia_type == 3:
                X[i] = 0.8 * np.random.normal(size=config.SEQUENCE_LENGTH)
            else:
                X[i] = base_ecg * (1 + 0.3 * np.sin(2 * np.pi * 2 * t)) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
        
        return X, y

def main():
    st.sidebar.title("Навигация")
    page = st.sidebar.selectbox("Выберите раздел:", 
                               ["Главная", "Загрузка данных", "Обучение моделей", 
                                "Прогнозирование", "Сравнение моделей", "О проекте"])
    
    data_loader = DataLoader()
    
    if page == "Главная":
        render_home_page()
        
    elif page == "Загрузка данных":
        render_data_loading_page(data_loader)
        
    elif page == "Обучение моделей":
        render_model_training_page()
        
    elif page == "Прогнозирование":
        render_prediction_page()
        
    elif page == "Сравнение моделей":
        render_comparison_page()
        
    elif page == "О проекте":
        render_about_page()

def render_home_page():
    st.header("Описание проекта")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Цель проекта")
        st.write("""
        Разработка рекомендательной системы для анализа 
        электрокардиограмм (ЭКГ) и классификации сердечных аритмий.
        
        **Основные задачи:**
        1. Загрузка и обработка биомедицинских данных
        2. Обучение моделей машинного обучения
        3. Создание интерфейса для прогнозирования
        4. Генерация рекомендаций
        """)
        
    with col2:
        st.subheader("Используемые технологии")
        st.write("""
        - **Python** - основной язык разработки
        - **Scikit-learn** - классические ML алгоритмы
        - **TensorFlow/Keras** - нейронные сети
        - **Streamlit** - веб-интерфейс
        - **Pandas/NumPy** - обработка данных
        - **Matplotlib/Seaborn** - визуализация
        """)
    
    st.markdown("---")
    
    st.subheader("Архитектура системы")
    st.image("https://raw.githubusercontent.com/streamlit/streamlit/develop/docs/logo.svg", 
             width=100)
    st.write("""
    Система состоит из следующих модулей:
    1. **Модуль загрузки данных** - получение и предобработка ЭКГ
    2. **Модуль извлечения признаков** - выделение характеристик сигналов
    3. **Модуль обучения** - тренировка моделей
    4. **Модуль прогнозирования** - классификация новых данных
    5. **Веб-интерфейс** - взаимодействие с пользователем
    """)

def render_data_loading_page(data_loader):
    st.header("📊 Загрузка и анализ данных")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Параметры данных")
        n_samples = st.slider("Количество образцов", 1000, 10000, 5000)
        
        if st.button("Загрузить данные"):
            with st.spinner("Загрузка данных..."):
                X, y = data_loader.load_simulated_data(n_samples)
                st.session_state.X = X
                st.session_state.y = y
                st.success(f"Загружено {n_samples} образцов!")
    
    if 'X' in st.session_state:
        X = st.session_state.X
        y = st.session_state.y
        
        with col2:
            st.subheader("Статистика")
            st.write(f"**Всего записей:** {len(X)}")
            st.write(f"**Длина сигнала:** {X.shape[1]} точек")
            st.write(f"**Количество классов:** {len(np.unique(y))}")
        
        st.subheader("Распределение классов")
        class_counts = pd.Series(y).value_counts().sort_index()
        
        fig, ax = plt.subplots(figsize=(10, 5))
        bars = ax.bar([config.ARRHYTHMIA_CLASSES[i] for i in class_counts.index], 
                     class_counts.values)
        ax.set_xlabel("Класс аритмии")
        ax.set_ylabel("Количество записей")
        ax.set_title("Распределение по классам")
        
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 5,
                   f'{int(height)}', ha='center', va='bottom')
        
        st.pyplot(fig)
        
        st.subheader("Примеры сигналов")
        show_samples = st.slider("Показать примеры для классов", 0, 4, 0)
        
        if st.button("Показать сигналы"):
            class_indices = np.where(y == show_samples)[0][:3]
            
            fig, axes = plt.subplots(1, 3, figsize=(15, 4))
            for idx, ax in zip(class_indices, axes):
                ax.plot(X[idx])
                ax.set_title(f"Сигнал {idx} - Класс {show_samples}")
                ax.set_xlabel("Время")
                ax.set_ylabel("Амплитуда")
            
            st.pyplot(fig)

def render_model_training_page():
    st.header("🤖 Обучение моделей")
    
    if 'X' not in st.session_state:
        st.warning("Сначала загрузите данные на вкладке 'Загрузка данных'")
        return
    
    X = st.session_state.X
    y = st.session_state.y
    
    # Разделение данных
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=config.TEST_SIZE, random_state=config.RANDOM_STATE
    )
    
    model_type = st.selectbox("Выберите тип модели:", 
                            ["Random Forest", "CNN (нейронная сеть)", "Обе модели"])
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Параметры Random Forest")
        n_estimators = st.slider("Количество деревьев", 50, 300, 100, key="rf_trees")
        max_depth = st.slider("Максимальная глубина", 5, 50, 10, key="rf_depth")
        
        if st.button("Обучить Random Forest"):
            with st.spinner("Обучение Random Forest..."):
                rf_model = RandomForestClassifier(
                    n_estimators=n_estimators,
                    max_depth=max_depth,
                    random_state=config.RANDOM_STATE
                )
                rf_model.fit(X_train, y_train)
                
                # Сохранение модели
                with open("models/model1.pkl", "wb") as f:
                    pickle.dump(rf_model, f)
                
                # Оценка
                y_pred = rf_model.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)
                
                st.session_state.rf_model = rf_model
                st.session_state.rf_accuracy = accuracy
                
                st.success(f"Random Forest обучен! Точность: {accuracy:.4f}")
                
                st.subheader("Метрики Random Forest")
                st.metric("Точность", f"{accuracy:.4f}")
                st.text(classification_report(y_test, y_pred))
    
    with col2:
        st.subheader("Параметры CNN")
        epochs = st.slider("Количество эпох", 5, 50, 10, key="cnn_epochs")
        batch_size = st.slider("Размер батча", 16, 128, 32, key="cnn_batch")
        
        if st.button("Обучить CNN"):
            with st.spinner("Обучение CNN... Это может занять несколько минут."):
                # Подготовка данных для CNN
                X_train_cnn = X_train.reshape(-1, config.SEQUENCE_LENGTH, 1)
                X_test_cnn = X_test.reshape(-1, config.SEQUENCE_LENGTH, 1)
                
                # Создание модели
                model = keras.Sequential([
                    keras.layers.Conv1D(32, 5, activation='relu', 
                                      input_shape=(config.SEQUENCE_LENGTH, 1)),
                    keras.layers.MaxPooling1D(2),
                    keras.layers.Conv1D(64, 3, activation='relu'),
                    keras.layers.GlobalAveragePooling1D(),
                    keras.layers.Dense(64, activation='relu'),
                    keras.layers.Dense(5, activation='softmax')
                ])
                
                model.compile(optimizer='adam',
                            loss='sparse_categorical_crossentropy',
                            metrics=['accuracy'])
                
                # Обучение
                history = model.fit(X_train_cnn, y_train, 
                                  epochs=epochs,
                                  batch_size=batch_size,
                                  validation_split=0.1,
                                  verbose=0)
                
                # Сохранение модели
                model.save("models/model2.h5")
                
                # Оценка
                test_loss, test_accuracy = model.evaluate(X_test_cnn, y_test, verbose=0)
                
                st.session_state.cnn_model = model
                st.session_state.cnn_accuracy = test_accuracy
                st.session_state.cnn_history = history.history
                
                st.success(f"CNN обучена! Точность: {test_accuracy:.4f}")
                
                st.subheader("Метрики CNN")
                st.metric("Точность", f"{test_accuracy:.4f}")
                
                # График обучения
                fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
                ax1.plot(history.history['accuracy'], label='Обучающая')
                ax1.plot(history.history['val_accuracy'], label='Валидационная')
                ax1.set_title('Точность модели')
                ax1.set_xlabel('Эпоха')
                ax1.legend()
                
                ax2.plot(history.history['loss'], label='Обучающая')
                ax2.plot(history.history['val_loss'], label='Валидационная')
                ax2.set_title('Функция потерь')
                ax2.set_xlabel('Эпоха')
                ax2.legend()
                
                st.pyplot(fig)

def render_prediction_page():
    st.header("🔍 Прогнозирование")
    
    # Загрузка моделей
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Загрузить Random Forest модель"):
            try:
                with open("models/model1.pkl", "rb") as f:
                    rf_model = pickle.load(f)
                st.session_state.rf_model_loaded = rf_model
                st.success("Random Forest модель загружена!")
            except:
                st.error("Модель не найдена. Сначала обучите модель.")
    
    with col2:
        if st.button("Загрузить CNN модель"):
            try:
                cnn_model = keras.models.load_model("models/model2.h5")
                st.session_state.cnn_model_loaded = cnn_model
                st.success("CNN модель загружена!")
            except:
                st.error("Модель не найдена. Сначала обучите модель.")
    
    st.subheader("Тестирование на новых данных")
    
    # Генерация тестового сигнала
    if st.button("Сгенерировать тестовый сигнал"):
        np.random.seed(42)
        t = np.linspace(0, 1, config.SEQUENCE_LENGTH)
        
        # Случайный тип аритмии
        arrhythmia_type = np.random.randint(0, 5)
        base_ecg = 0.5 * np.sin(2 * np.pi * 1 * t)
        
        if arrhythmia_type == 0:
            test_signal = base_ecg + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
        elif arrhythmia_type == 1:
            test_signal = base_ecg * (0.5 + 0.5 * np.sin(2 * np.pi * 0.1 * t)) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
        elif arrhythmia_type == 2:
            test_signal = base_ecg + 0.3 * np.random.normal(size=config.SEQUENCE_LENGTH) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
        elif arrhythmia_type == 3:
            test_signal = 0.8 * np.random.normal(size=config.SEQUENCE_LENGTH)
        else:
            test_signal = base_ecg * (1 + 0.3 * np.sin(2 * np.pi * 2 * t)) + 0.1 * np.random.normal(size=config.SEQUENCE_LENGTH)
        
        st.session_state.test_signal = test_signal
        st.session_state.true_label = arrhythmia_type
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(test_signal)
        ax.set_title(f"Тестовый сигнал (Истинный класс: {config.ARRHYTHMIA_CLASSES[arrhythmia_type]})")
        ax.set_xlabel("Время")
        ax.set_ylabel("Амплитуда")
        st.pyplot(fig)
    
    # Прогнозирование
    if 'test_signal' in st.session_state:
        st.subheader("Прогноз моделей")
        
        if st.button("Выполнить прогноз"):
            test_signal = st.session_state.test_signal
            
            results = []
            
            # Random Forest прогноз
            if 'rf_model_loaded' in st.session_state:
                rf_model = st.session_state.rf_model_loaded
                rf_pred = rf_model.predict(test_signal.reshape(1, -1))[0]
                rf_proba = rf_model.predict_proba(test_signal.reshape(1, -1))[0]
                rf_confidence = np.max(rf_proba)
                
                results.append({
                    'Модель': 'Random Forest',
                    'Предсказание': config.ARRHYTHMIA_CLASSES[rf_pred],
                    'Уверенность': f"{rf_confidence:.4f}"
                })
            
            # CNN прогноз
            if 'cnn_model_loaded' in st.session_state:
                cnn_model = st.session_state.cnn_model_loaded
                cnn_pred_proba = cnn_model.predict(test_signal.reshape(1, config.SEQUENCE_LENGTH, 1))[0]
                cnn_pred = np.argmax(cnn_pred_proba)
                cnn_confidence = np.max(cnn_pred_proba)
                
                results.append({
                    'Модель': 'CNN',
                    'Предсказание': config.ARRHYTHMIA_CLASSES[cnn_pred],
                    'Уверенность': f"{cnn_confidence:.4f}"
                })
            
            if results:
                results_df = pd.DataFrame(results)
                st.table(results_df)
                
                # Генерация рекомендации
                true_label = st.session_state.true_label
                st.info(f"**Истинный класс:** {config.ARRHYTHMIA_CLASSES[true_label]}")
                
                # Рекомендации
                recommendations = {
                    0: "✅ Ритм в норме. Рекомендуется плановое наблюдение.",
                    1: "⚠️ Обнаружены признаки апноэ. Рекомендуется консультация сомнолога.",
                    2: "🚨 Выявлена фибрилляция предсердий. Необходима срочная консультация кардиолога.",
                    3: "📢 Сигнал содержит значительный шум. Рекомендуется повторное измерение.",
                    4: "⚠️ Обнаружена другая аритмия. Требуется дополнительная диагностика."
                }
                
                st.success(f"**Рекомендация:** {recommendations.get(true_label, 'Требуется консультация специалиста.')}")

def render_comparison_page():
    st.header("📈 Сравнение моделей")
    
    comparison_data = []
    
    if 'rf_accuracy' in st.session_state:
        comparison_data.append({
            'Модель': 'Random Forest',
            'Точность': st.session_state.rf_accuracy,
            'Тип': 'Классическая ML'
        })
    
    if 'cnn_accuracy' in st.session_state:
        comparison_data.append({
            'Модель': 'CNN',
            'Точность': st.session_state.cnn_accuracy,
            'Тип': 'Нейронная сеть'
        })
    
    if comparison_data:
        df = pd.DataFrame(comparison_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Таблица сравнения")
            st.dataframe(df)
        
        with col2:
            st.subheader("График сравнения")
            fig, ax = plt.subplots(figsize=(8, 4))
            bars = ax.bar(df['Модель'], df['Точность'])
            ax.set_ylabel('Точность')
            ax.set_title('Сравнение точности моделей')
            ax.set_ylim(0, 1)
            
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                       f'{height:.4f}', ha='center', va='bottom')
            
            st.pyplot(fig)
        
        # Выводы
        st.subheader("Выводы")
        best_model = df.loc[df['Точность'].idxmax()]
        st.info(f"**Лучшая модель:** {best_model['Модель']} с точностью {best_model['Точность']:.4f}")
        
        if len(comparison_data) > 1:
            accuracy_diff = abs(comparison_data[0]['Точность'] - comparison_data[1]['Точность'])
            if accuracy_diff < 0.05:
                st.write("Модели показывают схожую производительность.")
            else:
                st.write(f"Разница в точности составляет {accuracy_diff:.4f}.")
    else:
        st.warning("Сначала обучите модели на вкладке 'Обучение моделей'")

def render_about_page():
    st.header("ℹ️ О проекте")
    
    st.markdown("""
    ### Дипломный проект
    
    **Тема:** Разработка рекомендательной системы на основе обработки биомедицинских данных
    
    **Автор:** Чайкин Виталий Федорович
    
    **Образовательное учреждение:** ЧОУВО «МУ им. С.Ю. Витте»
    
    **Руководитель:** Простомолотов Андрей Сергеевич
    
    **Период выполнения:** 10.11.2025 - 07.12.2025
    
    ---
    
    ### Технические требования
    
    **Язык программирования:** Python
    
    **Основные библиотеки:**
    - Streamlit - веб-интерфейс
    - Scikit-learn - машинное обучение
    - TensorFlow/Keras - нейронные сети
    - Pandas/NumPy - обработка данных
    - Matplotlib/Seaborn - визуализация
    
    **Требования к коду:**
    - Не менее 2000 строк кода
    - Сохранение моделей в файлы
    - Загрузка данных из внешних источников
    - Git репозиторий с 50+ коммитами
    
    **Метрики качества:**
    - Accuracy >= 70%
    - Время обучения < 6 часов
    - Подробные комментарии на русском языке
    """)
    
    st.sidebar.markdown("---")
    st.sidebar.info("""
    **Контакты:**
    - Email: [ваш email]
    - GitHub: [ваш репозиторий]
    - Телефон: [ваш телефон]
    """)

if __name__ == "__main__":
    main()