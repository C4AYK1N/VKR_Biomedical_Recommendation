"""
Веб-интерфейс приложения на Streamlit.
Автор: Чайкин Виталий Федорович
Тема ВКР: Разработка рекомендательной системы на основе обработки биомедицинских данных
"""

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import sys
import os

# Добавляем путь к корневой директории проекта
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from app.core.data_loader import BiomedicalDataLoader
from app.core.feature_engineer import ECGFeatureEngineer
from app.core.model_loader import ModelLoader
from app.services.training_service import TrainingService
from app.services.prediction_service import PredictionService
from utils.config import Config

class BiomedicalApp:
    """Класс веб-приложения для анализа ЭКГ."""
    
    def __init__(self):
        self.config = Config()
        self.setup_page()
        self.initialize_services()
        
    def setup_page(self):
        """Настройка страницы Streamlit."""
        st.set_page_config(
            page_title="Рекомендательная система для анализа ЭКГ",
            page_icon="❤️",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        st.title("❤️ Рекомендательная система для анализа биомедицинских данных")
        st.markdown("---")
        
    def initialize_services(self):
        """Инициализация сервисов."""
        if 'initialized' not in st.session_state:
            self.data_loader = BiomedicalDataLoader()
            self.feature_engineer = ECGFeatureEngineer()
            self.model_loader = ModelLoader()
            self.training_service = TrainingService(self.model_loader, self.feature_engineer)
            self.prediction_service = PredictionService(
                self.model_loader, self.feature_engineer, self.data_loader
            )
            
            # Загрузка демо данных
            with st.spinner("Загрузка данных..."):
                self.X, self.y = self.data_loader.download_dataset()
                self.X_train, self.X_val, self.X_test, self.y_train, self.y_val, self.y_test = \
                    self.data_loader.split_data(self.X, self.y)
            
            st.session_state.initialized = True
            st.session_state.models_trained = False
            st.session_state.current_tab = "data_analysis"
    
    def render_sidebar(self):
        """Отрисовка боковой панели."""
        st.sidebar.title("Навигация")
        
        tabs = {
            "📊 Анализ данных": "data_analysis",
            "🤖 Обучение моделей": "model_training", 
            "🔍 Прогнозирование": "prediction",
            "📈 Сравнение моделей": "model_comparison",
            "ℹ️ О проекте": "about"
        }
        
        selected_tab = st.sidebar.radio("Выберите раздел:", list(tabs.keys()))
        st.session_state.current_tab = tabs[selected_tab]
        
        st.sidebar.markdown("---")
        st.sidebar.info(
            "Разработка рекомендательной системы на основе обработки "
            "биомедицинских данных"
        )
    
    def render_data_analysis_tab(self):
        """Вкладка анализа данных."""
        st.header("📊 Анализ данных ЭКГ")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Статистика датасета")
            
            # Основная информация о данных
            info_data = {
                "Общее количество записей": len(self.X),
                "Количество признаков": self.X.shape[1],
                "Количество классов": len(np.unique(self.y)),
                "Размер обучающей выборки": len(self.X_train),
                "Размер тестовой выборки": len(self.X_test),
                "Размер валидационной выборки": len(self.X_val)
            }
            
            for key, value in info_data.items():
                st.write(f"**{key}:** {value}")
        
        with col2:
            st.subheader("Распределение классов")
            
            # Круговоя диаграмма распределения классов
            class_counts = pd.Series(self.y).value_counts().sort_index()
            class_names = [self.config.ARRHYTHMIA_CLASSES[i] for i in class_counts.index]
            
            fig_pie = go.Figure(data=[go.Pie(
                labels=class_names,
                values=class_counts.values,
                hole=.3
            )])
            fig_pie.update_layout(title="Распределение классов аритмий")
            st.plotly_chart(fig_pie, use_container_width=True)
        
        # Визуализация примеров сигналов
        st.subheader("Примеры сигналов ЭКГ по классам")
        
        classes_to_show = min(5, len(self.config.ARRHYTHMIA_CLASSES))
        cols = st.columns(classes_to_show)
        
        for i, class_id in enumerate(list(self.config.ARRHYTHMIA_CLASSES.keys())[:classes_to_show]):
            with cols[i]:
                # Находим первый пример данного класса
                class_indices = np.where(self.y == class_id)[0]
                if len(class_indices) > 0:
                    example_signal = self.X[class_indices[0]]
                    class_name = self.config.ARRHYTHMIA_CLASSES[class_id]
                    
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        y=example_signal,
                        mode='lines',
                        name=class_name,
                        line=dict(color='blue' if class_id == 0 else 'red')
                    ))
                    fig.update_layout(
                        title=f"Класс: {class_name}",
                        height=200,
                        showlegend=False
                    )
                    st.plotly_chart(fig, use_container_width=True)
        
        # Статистика по признакам
        if st.checkbox("Показать расширенную статистику"):
            st.subheader("Статистический анализ признаков")
            
            # Создаем датасет признаков для анализа
            with st.spinner("Извлечение признаков..."):
                features_sample = self.feature_engineer.create_feature_dataset(self.X[:100])  # Берем sample для скорости
            
            feature_stats = pd.DataFrame({
                'Среднее': np.mean(features_sample, axis=0),
                'Стандартное отклонение': np.std(features_sample, axis=0),
                'Минимум': np.min(features_sample, axis=0),
                'Максимум': np.max(features_sample, axis=0)
            })
            
            st.dataframe(feature_stats.head(10))
    
    def render_model_training_tab(self):
        """Вкладка обучения моделей."""
        st.header("🤖 Обучение моделей")
        
        # Выбор типа модели
        model_type = st.selectbox(
            "Выберите тип модели:",
            ["Random Forest", "CNN (нейронная сеть)"],
            key="model_type_select"
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Параметры обучения")
            
            if model_type == "Random Forest":
                n_estimators = st.slider("Количество деревьев", 50, 300, 100)
                max_depth = st.slider("Максимальная глубина", 5, 20, 10)
                use_feature_engineering = st.checkbox("Использовать извлеченные признаки", value=True)
                
                train_button = st.button("Обучить Random Forest", type="primary")
                
                if train_button:
                    with st.spinner("Обучение Random Forest..."):
                        # Подготовка данных
                        if use_feature_engineering:
                            X_train_processed = self.feature_engineer.create_feature_dataset(self.X_train)
                            X_val_processed = self.feature_engineer.create_feature_dataset(self.X_val)
                        else:
                            X_train_processed = self.X_train
                            X_val_processed = self.X_val
                        
                        # Обучение модели
                        rf_model, history = self.training_service.train_random_forest(
                            X_train_processed, self.y_train,
                            X_val_processed, self.y_val,
                            n_estimators=n_estimators,
                            max_depth=max_depth
                        )
                        
                        # Сохранение модели
                        model_path = "models/model1.pkl"
                        self.model_loader.save_model(rf_model, model_path)
                        
                        # Оценка модели
                        metrics = self.training_service.evaluate_model_comprehensive(
                            rf_model, X_val_processed, self.y_val
                        )
                        
                        # Сохранение результатов в session state
                        st.session_state.rf_model = rf_model
                        st.session_state.rf_history = history
                        st.session_state.rf_metrics = metrics
                        st.session_state.models_trained = True
                        
                        st.success("Модель успешно обучена!")
                        
                        # Показ метрик
                        self._display_training_results(history, metrics, "Random Forest")
            
            else:  # CNN
                epochs = st.slider("Количество эпох", 10, 100, 30)
                batch_size = st.slider("Размер батча", 16, 128, 32)
                
                train_button = st.button("Обучить CNN", type="primary")
                
                if train_button:
                    with st.spinner("Обучение CNN... Это может занять несколько минут."):
                        # Обучение CNN
                        cnn_model, history = self.training_service.train_cnn_model(
                            self.X_train, self.y_train,
                            self.X_val, self.y_val,
                            epochs=epochs,
                            batch_size=batch_size
                        )
                        
                        # Сохранение модели
                        model_path = "models/model2.h5"
                        self.model_loader.save_model(cnn_model, model_path)
                        
                        # Оценка модели
                        metrics = self.training_service.evaluate_model_comprehensive(
                            cnn_model, self.X_val, self.y_val, model_type='keras'
                        )
                        
                        # Сохранение результатов
                        st.session_state.cnn_model = cnn_model
                        st.session_state.cnn_history = history
                        st.session_state.cnn_metrics = metrics
                        st.session_state.models_trained = True
                        
                        st.success("CNN модель успешно обучена!")
                        
                        # Показ результатов
                        self._display_training_results(history, metrics, "CNN")
        
        with col2:
            st.subheader("Результаты обучения")
            
            if st.session_state.get('models_trained', False):
                if 'rf_metrics' in st.session_state:
                    st.info("**Random Forest результаты:**")
                    metrics = st.session_state.rf_metrics
                    st.metric("Точность", f"{metrics['accuracy']:.4f}")
                    st.metric("Precision", f"{metrics['precision']:.4f}")
                    st.metric("Recall", f"{metrics['recall']:.4f}")
                    st.metric("F1-Score", f"{metrics['f1_score']:.4f}")
                
                if 'cnn_history' in st.session_state:
                    st.info("**CNN результаты:**")
                    self.training_service.plot_training_history(st.session_state.cnn_history)
    
    def _display_training_results(self, history, metrics, model_name):
        """Отображение результатов обучения."""
        st.subheader(f"Результаты {model_name}")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Точность", f"{metrics['accuracy']:.4f}")
        with col2:
            st.metric("Precision", f"{metrics['precision']:.4f}")
        with col3:
            st.metric("Recall", f"{metrics['recall']:.4f}")
        with col4:
            st.metric("F1-Score", f"{metrics['f1_score']:.4f}")
        
        # Матрица ошибок
        st.subheader("Матрица ошибок")
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(
            metrics['confusion_matrix'],
            annot=True, fmt='d', cmap='Blues',
            xticklabels=list(self.config.ARRHYTHMIA_CLASSES.values()),
            yticklabels=list(self.config.ARRHYTHMIA_CLASSES.values())
        )
        ax.set_xlabel('Предсказанные метки')
        ax.set_ylabel('Истинные метки')
        st.pyplot(fig)
        
        # Отчет о классификации
        st.subheader("Отчет о классификации")
        st.text(metrics['classification_report'])
    
    def render_prediction_tab(self):
        """Вкладка прогнозирования."""
        st.header("🔍 Прогнозирование аритмий")
        
        # Загрузка моделей
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Загрузка моделей")
            
            if st.button("Загрузить Random Forest модель"):
                model_path = "models/model1.pkl"
                if os.path.exists(model_path):
                    success = self.prediction_service.load_model(model_path, "random_forest")
                    if success:
                        st.success("Random Forest модель загружена!")
                    else:
                        st.error("Ошибка при загрузке модели")
                else:
                    st.warning("Файл модели не найден. Сначала обучите модель.")
            
            if st.button("Загрузить CNN модель"):
                model_path = "models/model2.h5"
                if os.path.exists(model_path):
                    success = self.prediction_service.load_model(model_path, "cnn")
                    if success:
                        st.success("CNN модель загружена!")
                    else:
                        st.error("Ошибка при загрузке модели")
                else:
                    st.warning("Файл модели не найден. Сначала обучите модель.")
        
        with col2:
            st.subheader("Загруженные модели")
            for model_name in ["random_forest", "cnn"]:
                model_info = self.prediction_service.get_model_info(model_name)
                if model_info['loaded']:
                    st.success(f"✓ {model_name} ({model_info['type']})")
                else:
                    st.info(f"○ {model_name} (не загружена)")
        
        # Прогнозирование
        st.subheader("Прогнозирование на новых данных")
        
        prediction_method = st.radio(
            "Выберите метод ввода данных:",
            ["Случайный пример из тестовой выборки", "Загрузить свой файл"]
        )
        
        if prediction_method == "Случайный пример из тестовой выборки":
            if st.button("Сгенерировать случайный пример"):
                random_idx = np.random.randint(0, len(self.X_test))
                test_signal = self.X_test[random_idx]
                true_label = self.y_test[random_idx]
                
                st.session_state.current_signal = test_signal
                st.session_state.true_label = true_label
                
                # Визуализация сигнала
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    y=test_signal,
                    mode='lines',
                    name='ЭКГ сигнал',
                    line=dict(color='blue')
                ))
                fig.update_layout(
                    title="Тестовый сигнал ЭКГ",
                    xaxis_title="Отсчеты",
                    yaxis_title="Амплитуда"
                )
                st.plotly_chart(fig, use_container_width=True)
                
                st.write(f"**Истинный класс:** {self.config.ARRHYTHMIA_CLASSES[true_label]}")
        
        else:
            uploaded_file = st.file_uploader("Загрузите файл с данными ЭКГ", type=['csv', 'txt'])
            if uploaded_file is not None:
                try:
                    # Загрузка и обработка файла
                    data = pd.read_csv(uploaded_file)
                    if len(data.columns) > 0:
                        signal = data.iloc[:, 0].values
                        if len(signal) > self.config.SEQUENCE_LENGTH:
                            signal = signal[:self.config.SEQUENCE_LENGTH]
                        elif len(signal) < self.config.SEQUENCE_LENGTH:
                            # Дополняем нулями если нужно
                            signal = np.pad(signal, (0, self.config.SEQUENCE_LENGTH - len(signal)))
                        
                        st.session_state.current_signal = signal
                        
                        # Визуализация
                        fig = go.Figure()
                        fig.add_trace(go.Scatter(
                            y=signal,
                            mode='lines',
                            name='Загруженный сигнал ЭКГ'
                        ))
                        fig.update_layout(
                            title="Загруженный сигнал ЭКГ",
                            xaxis_title="Отсчеты",
                            yaxis_title="Амплитуда"
                        )
                        st.plotly_chart(fig, use_container_width=True)
                
                except Exception as e:
                    st.error(f"Ошибка при обработке файла: {str(e)}")
        
        # Выполнение прогноза
        if 'current_signal' in st.session_state:
            st.subheader("Прогноз модели")
            
            selected_models = st.multiselect(
                "Выберите модели для прогнозирования:",
                ["random_forest", "cnn"],
                default=["random_forest"]
            )
            
            if st.button("Выполнить прогноз", type="primary"):
                for model_name in selected_models:
                    if self.prediction_service.get_model_info(model_name)['loaded']:
                        result = self.prediction_service.predict_single_ecg(
                            st.session_state.current_signal, model_name
                        )
                        
                        if result['success']:
                            st.success(f"**Результат {model_name}:**")
                            
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.write(f"**Тип аритмии:** {result['arrhythmia_type']}")
                                st.write(f"**Уверенность:** {result['confidence']:.4f}")
                            
                            with col2:
                                # Визуализация вероятностей
                                prob_df = pd.DataFrame({
                                    'Класс': list(result['probabilities'].keys()),
                                    'Вероятность': list(result['probabilities'].values())
                                })
                                
                                fig = go.Figure(go.Bar(
                                    x=prob_df['Вероятность'],
                                    y=prob_df['Класс'],
                                    orientation='h'
                                ))
                                fig.update_layout(
                                    title=f"Вероятности классов ({model_name})",
                                    xaxis_title="Вероятность",
                                    height=300
                                )
                                st.plotly_chart(fig, use_container_width=True)
                            
                            st.info(f"**Рекомендация:** {result['recommendation']}")
                        else:
                            st.error(f"Ошибка: {result['error']}")
                    else:
                        st.warning(f"Модель {model_name} не загружена")
    
    def render_model_comparison_tab(self):
        """Вкладка сравнения моделей."""
        st.header("📈 Сравнение моделей")
        
        if not st.session_state.get('models_trained', False):
            st.warning("Сначала обучите модели во вкладке 'Обучение моделей'")
            return
        
        # Сравнение метрик
        st.subheader("Сравнение метрик производительности")
        
        comparison_data = []
        
        if 'rf_metrics' in st.session_state:
            comparison_data.append({
                'Модель': 'Random Forest',
                'Точность': st.session_state.rf_metrics['accuracy'],
                'Precision': st.session_state.rf_metrics['precision'],
                'Recall': st.session_state.rf_metrics['recall'],
                'F1-Score': st.session_state.rf_metrics['f1_score']
            })
        
        if 'cnn_metrics' in st.session_state:
            comparison_data.append({
                'Модель': 'CNN',
                'Точность': st.session_state.cnn_metrics['accuracy'],
                'Precision': st.session_state.cnn_metrics['precision'],
                'Recall': st.session_state.cnn_metrics['recall'],
                'F1-Score': st.session_state.cnn_metrics['f1_score']
            })
        
        if comparison_data:
            comparison_df = pd.DataFrame(comparison_data)
            st.dataframe(comparison_df.set_index('Модель'))
            
            # Визуализация сравнения
            metrics_to_plot = ['Точность', 'Precision', 'Recall', 'F1-Score']
            fig = go.Figure()
            
            for metric in metrics_to_plot:
                fig.add_trace(go.Bar(
                    name=metric,
                    x=comparison_df['Модель'],
                    y=comparison_df[metric]
                ))
            
            fig.update_layout(
                title="Сравнение метрик моделей",
                barmode='group',
                xaxis_title="Модель",
                yaxis_title="Значение метрики"
            )
            st.plotly_chart(fig, use_container_width=True)
    
    def render_about_tab(self):
        """Вкладка о проекте."""
        st.header("ℹ️ О проекте")
        
        st.markdown("""
        ## Разработка рекомендательной системы на основе обработки биомедицинских данных
        
        ### Описание проекта
        Данный проект представляет собой интеллектуальную систему для анализа электрокардиограмм (ЭКГ) 
        и классификации различных типов сердечных аритмий.
        
        ### Функциональные возможности:
        - 📊 **Анализ и визуализация** биомедицинских данных
        - 🤖 **Обучение моделей** машинного обучения (Random Forest, CNN)
        - 🔍 **Прогнозирование** типов аритмий по новым данным
        - 📈 **Сравнение производительности** различных моделей
        - 💡 **Генерация рекомендаций** на основе результатов анализа
        
        ### Используемые технологии:
        - **Python** - основной язык программирования
        - **Scikit-learn** - классические алгоритмы ML
        - **TensorFlow/Keras** - глубокое обучение
        - **Streamlit** - веб-интерфейс
        - **Plotly** - интерактивная визуализация
        
        ### Метрики качества:
        - Точность (Accuracy)
        - Precision, Recall, F1-Score
        - Матрица ошибок
        - ROC-кривые
        
        ### Классифицируемые типы аритмий:
        1. Нормальный ритм
        2. Апноэ
        3. Фибрилляция предсердий
        4. Шум
        5. Другая аритмия
        """)
        
        st.markdown("---")
        st.info("""
        **Разработчик:** [Ваше ФИО]  
        **Образовательное учреждение:** ЧОУВО «МУ им. С.Ю. Витте»  
        **Руководитель:** Простомолотов Андрей Сергеевич  
        **Период реализации:** 10.11.2025 - 07.12.2025
        """)
    
    def run(self):
        """Запуск приложения."""
        self.render_sidebar()
        
        current_tab = st.session_state.current_tab
        
        if current_tab == "data_analysis":
            self.render_data_analysis_tab()
        elif current_tab == "model_training":
            self.render_model_training_tab()
        elif current_tab == "prediction":
            self.render_prediction_tab()
        elif current_tab == "model_comparison":
            self.render_model_comparison_tab()
        elif current_tab == "about":
            self.render_about_tab()

def main():
    """Основная функция запуска приложения."""
    app = BiomedicalApp()
    app.run()

if __name__ == "__main__":
    main()